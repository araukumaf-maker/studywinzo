#!/data/data/com.termux/files/usr/bin/bash
# StudyWinzo — Auto Server Start Script

cd ~/studywinzo

echo ""
echo "════════════════════════════════════════"
echo "  🚀 StudyWinzo Server Starting..."
echo "════════════════════════════════════════"
echo ""

# Clean old processes
pkill -9 php 2>/dev/null
pkill -9 ngrok 2>/dev/null
sleep 1

# Start PHP server in background
echo "📡 PHP server starting on 127.0.0.1:9003..."
nohup php -S 127.0.0.1:9003 > ~/studywinzo/server.log 2>&1 &
sleep 2

# Check PHP running
if pgrep -f "php -S" > /dev/null; then
    echo "✅ PHP server running (PID: $(pgrep -f 'php -S'))"
else
    echo "❌ PHP server failed to start"
    cat ~/studywinzo/server.log
    exit 1
fi

# Start ngrok in background
echo ""
echo "🌐 ngrok starting..."
nohup ~/paytm_qr/ngrok http --url=scoreless-trousers-aviation.ngrok-free.dev 9003 > ~/studywinzo/ngrok.log 2>&1 &
sleep 5

# Check ngrok running
if pgrep -f ngrok > /dev/null; then
    echo "✅ ngrok running (PID: $(pgrep -f ngrok))"
else
    echo "❌ ngrok failed to start"
    cat ~/studywinzo/ngrok.log
    exit 1
fi

echo ""
echo "════════════════════════════════════════"
echo "  ✅ SERVER READY"
echo "════════════════════════════════════════"
echo ""
echo "  🌐 Local:  http://127.0.0.1:9003"
echo "  🌍 Public: https://scoreless-trousers-aviation.ngrok-free.dev"
echo "  🔐 Admin:  https://scoreless-trousers-aviation.ngrok-free.dev/admin/"
echo ""
echo "  📋 Logs:"
echo "     tail -f ~/studywinzo/server.log"
echo "     tail -f ~/studywinzo/ngrok.log"
echo ""
echo "  🛑 Stop: bash ~/studywinzo/stop.sh"
echo ""
echo "════════════════════════════════════════"
